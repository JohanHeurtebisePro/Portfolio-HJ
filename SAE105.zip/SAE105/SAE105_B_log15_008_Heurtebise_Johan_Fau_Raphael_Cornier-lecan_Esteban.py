def analyser_fichier(fichier, fichier_sortie, fichier_texte):
    #Ouverture du fichier log 
    with open(fichier, 'r') as file:
        lignes = file.readlines()

    # Initialisation des compteurs et des dictionnaires pour l'analyse
    send_count = 0  #cpt
    received_count = 0  #cpt
    ip_counts = {}  #dico
    date_counts = {}    #dico
    creneaux_counts = {"0h-6h": 0, "7h-12h": 0, "13h-18h": 0, "19h-23h": 0} #dico
    protocoles_counts = {}  #dico

    # Analyse des lignes du fichier
    for ligne in lignes:    #Pour toutes les lignes du fichier
        colonnes = ligne.split("\t")  #Séparation des colonnes
        
        #Cas classique avec 6 colonnes
        if len(colonnes) >= 6:
            protocole = colonnes[0].strip()  #Pprotocole
            date_heure = colonnes[3].strip()  #Date et heure
            ip = colonnes[4].strip()  #Adresse IP
            action = colonnes[5].strip()  #SENT ou RECEIVED

            # Comptage SENT et RECEIVED
            if "SENT" in action:  #Si c'est SENT
                send_count += 1
            if "RECEIVED" in action:    #Si c'est RECEIVED
                received_count += 1

            #Comptage adresse IP
            if ip in ip_counts: #Si IP est dans le dico ip_count
                ip_counts[ip] += 1  #+1 
            else:
                ip_counts[ip] = 1   #Sinon on l'ajoute avec 1

            #Compteur date
            date = date_heure.split(" ")[0]  #Extraction de la date dans la variable date
            if date in date_counts: #Si la date est dans le dico date_counts
                date_counts[date] += 1  #+1
            else:
                date_counts[date] = 1   #Sinon on l'ajoute avec 1

            # Compteur créneaux horaires
            heure = int(date_heure.split(" ")[1].split(":")[0])  #Extraction de l'heure
            if 0 <= heure <= 6:
                creneaux_counts["0h-6h"] += 1   #+1 à la values
            elif 7 <= heure <= 12:
                creneaux_counts["7h-12h"] += 1  
            elif 13 <= heure <= 18:
                creneaux_counts["13h-18h"] += 1 
            elif 19 <= heure <= 24:
                creneaux_counts["19h-23h"] += 1

            # Compteur Protocole
            if protocole in protocoles_counts:  #Si protocole est dans le dico protocoles_counts
                protocoles_counts[protocole] += 1
            else:
                protocoles_counts[protocole] = 1

        # Cas alternatif avec 4 colonnes (rare)
        elif len(colonnes) >= 4:
            protocole = colonnes[0].strip()  # Extraction protocole dans la variable protocole
            date_heure = colonnes[2].strip()  # Extraction date et heure

            # Compteur date
            date = date_heure.split(" ")[0] #Extraction date dans la variable date
            if date in date_counts: #Si date est dans le dico
                date_counts[date] += 1  #+1 à la values de date
            else:   
                date_counts[date] = 1   #Sinon, on l'ajoute avec la valeur 1

            # Compteur créneaux horaires
            heure = int(date_heure.split(" ")[1].split(":")[0]) #2023-03-04 12:16:26.134 puis 12:16:26.134 puis 12
            if 0 <= heure <= 6:
                creneaux_counts["0h-6h"] += 1       #+1 dans values
            elif 7 <= heure <= 12:
                creneaux_counts["7h-12h"] += 1
            elif 13 <= heure <= 18:
                creneaux_counts["13h-18h"] += 1
            elif 19 <= heure <= 24:
                creneaux_counts["19h-23h"] += 1

            #Compteur protocole
            if protocole in protocoles_counts:  #Si le protocole est dans le dico 
                protocoles_counts[protocole] += 1   #+1
            else:
                protocoles_counts[protocole] = 1    #On l'ajoute avec la valeur 1

    #Calcul Stats
    total_messages = 0  #Total=0
    for valeur in date_counts.values():  #Pour toutes les valeurs du dico des dates
        total_messages += valeur  #Ajoute la valeur au cpt total
    moyenne_par_jour = total_messages / len(date_counts)  #Moyenne jours

    #Résumé fichier txt
    resume_txt = [] #Création d'une liste
    resume_txt.append("\n=== Résumé de l'Analyse ===")
    resume_txt.append(f"Nombre total de lignes : {len(lignes)}")
    resume_txt.append(f"Nombre de fois 'SENT' : {send_count}")
    resume_txt.append(f"Nombre de fois 'RECEIVED' : {received_count}")
    resume_txt.append(f"Moyenne de messages par jour : {moyenne_par_jour:.2f}") #2nbr après la ,

    #Stats fichier txt
    resume_txt.append("\n=== Répartition par IP ===")
    for ip, count in ip_counts.items(): #Pour tout les ip, leur nbr d'occurence dans le dico
        resume_txt.append(f"{ip} : {count} fois")   #Ajout de IP et du nbr dans fichier txt

    resume_txt.append("\n=== Répartition par date ===")
    for date, count in date_counts.items(): #Pour tout les date, leur nbr dans le dico
        resume_txt.append(f"{date} : {count} fois") #Ajout de date et du nbr dans fichier txt

    resume_txt.append("\n=== Répartition par créneaux horaires ===")
    for creneau, count in creneaux_counts.items():
        resume_txt.append(f"{creneau} : {count} fois")

    resume_txt.append("\n=== Répartition par protocoles ===")
    for protocole, count in protocoles_counts.items():
        resume_txt.append(f"{protocole} : {count} fois")

    #Écriture dans fichier txt
    with open(fichier_texte, "w") as file_txt:
        for ligne in resume_txt:
            file_txt.write(ligne + "\n")

    #Affichage console
    for ligne in resume_txt:
        print(ligne)

    #Création d'un dicto pour le html
    context = {
        "send_count": send_count,
        "received_count": received_count,
        "ip_labels": list(ip_counts.keys()),
        "ip_values": list(ip_counts.values()),
        "date_labels": list(date_counts.keys()),
        "date_values": list(date_counts.values()),
        "creneaux_labels": list(creneaux_counts.keys()),
        "creneaux_values": list(creneaux_counts.values()),
        "protocoles_labels": list(protocoles_counts.keys()),
        "protocoles_values": list(protocoles_counts.values()),
        "moyenne_par_jour": f"{moyenne_par_jour:.2f}", #2nbr après la ,
        "nb_lignes": len(lignes),
    }

    #Appel pour html
    generer_html(fichier_sortie, context)





def generer_html(fichier_sortie, context):
    html_contenu = f"""
    <html>
    <head>
        <title>Analyse du fichier</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <link rel="stylesheet" href="SAE105_CSS.css">
    </head>
    <body>
        <header>
            <h1>Analyse de fichier Log</h1>
            <p>Visualisez et comprenez vos données facilement</p>
        </header>

        <nav>
            <a href="#resume">Résumé</a>
            <a href="#protocoles">Protocoles</a>
            <a href="#ip">Adresses IP</a>
            <a href="#dates">Dates</a>
            <a href="#creneaux">Créneaux horaires</a>
        </nav>

        <main>
            <section id="resume">
                <h2>Résumé du fichier de Log</h2>
                <div class="resu">
                    <p>Nombre de lignes du fichier : <span class="res">{context['nb_lignes']}</span></p>
                    <p>Nombre de fois 'SENT' : <span class="res">{context['send_count']}</span></p>
                    <p>Nombre de fois 'RECEIVED' : <span class="res">{context['received_count']}</span></p>
                    <p>Moyenne de messages par jour : <span class="res">{context['moyenne_par_jour']}</span></p>
                    <p>Ce fichier log est un fichier extrait d'une messagerie en ligne, où nous pouvons voir divers informations tels que le protocole utilisé,
                    l'adresse IP source, des dates, des ID, etc...</p>
                </div>

            </section>
            <table border="1">
                    <thead>
                        <tr>
                            <th>Adresse IP</th>
                            <th>Occurrences</th>
                        </tr>
                    </thead>
                    <tbody>
                        {''.join(f'<tr><td>{ip}</td><td>{count}</td></tr>' for ip, count in zip(context['ip_labels'], context['ip_values']))}
                    </tbody>
                </table>
            
            <section id="protocoles">
                <h2>Répartition des messages par protocole</h2>
                <div class="chart">
                    <canvas id="chartProtocoles"></canvas>
                </div>
            </section>

            <section id="ip">
                <h2>Répartition des messages par adresse IP</h2>
                <div class="chart">
                    <canvas id="chartIP"></canvas>
                </div>
            </section>

            <section id="dates">
                <h2>Répartition des messages par date</h2>
                <div class="chart">
                    <canvas id="chartDate"></canvas>
                </div>
            </section>

            <section id="creneaux">
                <h2>Répartition des messages par créneaux horaires</h2>
                <div class="chart">
                    <canvas id="chartCreneaux"></canvas>
                </div>
            </section>
        </main>

        <footer>
            <p>Heurtebise Johan - Fau Raphael - Cornier-Lecan Esteban</p>
        </footer>

        <script>
            new Chart(document.getElementById('chartProtocoles'), {{
                type: 'pie',
                data: {{
                    labels: {context['protocoles_labels']},
                    datasets: [{{
                        data: {context['protocoles_values']},
                        backgroundColor: ['rgba(231, 76, 60, 0.5)', 'rgba(46, 204, 113, 0.5)', 'rgba(52, 152, 219, 0.5)', 'rgba(155, 89, 182, 0.5)', 'rgba(241, 196, 15, 0.5)']
                    }}]
                }}
            }});

            new Chart(document.getElementById('chartIP'), {{
                type: 'bar',
                data: {{
                    labels: {context['ip_labels']},
                    datasets: [{{
                        label: "Occurrence par IP",
                        data: {context['ip_values']},
                        backgroundColor: 'rgba(52, 152, 219, 0.7)'
                    }}]
                }}
            }});

            new Chart(document.getElementById('chartDate'), {{
                type: 'line',
                data: {{
                    labels: {context['date_labels']},
                    datasets: [{{
                        label: "Occurrence par date",
                        data: {context['date_values']},
                        backgroundColor: 'rgba(46, 204, 113, 0.7)'
                    }}]
                }}
            }});

            new Chart(document.getElementById('chartCreneaux'), {{
                type: 'pie',
                data: {{
                    labels: {context['creneaux_labels']},
                    datasets: [{{
                        data: {context['creneaux_values']},
                        backgroundColor: ['rgba(231, 76, 60, 0.7)', 'rgba(46, 204, 113, 0.7)', 'rgba(52, 152, 219, 0.7)', 'rgba(155, 89, 182, 0.7)']
                    }}]
                }}
            }});
        </script>
    </body>
    </html>
    """
    #Ecriture fichier html
    with open(fichier_sortie, "w", encoding="utf-8") as file:
        file.write(html_contenu)




fichier = "Log.log"
fichier_sortie = "resultats.html"
fichier_texte = "resultats.txt"
analyser_fichier(fichier, fichier_sortie, fichier_texte)

#.join --> mettre en une seule chaine
#zip --> assemble 2 listes en tuple
